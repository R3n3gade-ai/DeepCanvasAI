export class GoogleSearchTool {
    
    getDeclaration() {
        return { 
            name: 'googleSearch',
        };
    }

    execute(args) {
        return;
    }
}